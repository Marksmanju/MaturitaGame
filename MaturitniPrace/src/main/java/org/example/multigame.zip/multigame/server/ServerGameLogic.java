package org.example.multigame.server;

import org.example.multigame.shared.GameState;
import org.example.multigame.shared.PlayerInput;
import org.example.multigame.shared.PlayerState;

public class ServerGameLogic {
    public GameState state = new GameState();
    private final int speed = 5;

    public ServerGameLogic() {
        state.player1 = new PlayerState(50, 50);
        state.player2 = new PlayerState(200, 50);
    }

    public synchronized void applyInput(PlayerInput input, int playerId) {
        PlayerState p = (playerId == 1) ? state.player1 : state.player2;
        System.out.println("Input is applied");
        if (input.up) p.y -= speed;
        if (input.down) p.y += speed;
        if (input.left) p.x -= speed;
        if (input.right) p.x += speed;
    }
}