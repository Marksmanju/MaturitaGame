package org.example.multigame.shared;

import java.io.Serializable;
public class GameState implements Serializable{
    public PlayerState player1;
    public PlayerState player2;
}
