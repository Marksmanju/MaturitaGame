package org.example.multigame.client;

public class ClientGameLogic {
}
