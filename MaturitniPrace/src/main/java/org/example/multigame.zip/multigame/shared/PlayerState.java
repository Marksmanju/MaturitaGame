package org.example.multigame.shared;

import java.io.Serializable;

public class PlayerState implements Serializable {
    public int x, y;

    public PlayerState(int x, int y) {
        this.x = x;
        this.y = y;
    }

}
