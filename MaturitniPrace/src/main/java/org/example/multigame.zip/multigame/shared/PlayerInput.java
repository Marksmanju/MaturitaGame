package org.example.multigame.shared;

import java.io.Serializable;

public class PlayerInput implements Serializable {
    public boolean up, down, left, right;
}
