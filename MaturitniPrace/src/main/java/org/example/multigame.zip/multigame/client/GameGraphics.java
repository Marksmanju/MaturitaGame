package org.example.multigame.client;

import org.example.multigame.shared.GameState;

import javax.swing.*;
import java.awt.*;

public class GameGraphics extends JPanel {
    private GameState state;

    public void updateState(GameState state) {
        this.state = state;
        repaint();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (state == null) return;

        g.setColor(Color.RED);
        g.fillRect(state.player1.x, state.player1.y, 20, 20);

        g.setColor(Color.BLUE);
        g.fillRect(state.player2.x, state.player2.y, 20, 20);
    }
}