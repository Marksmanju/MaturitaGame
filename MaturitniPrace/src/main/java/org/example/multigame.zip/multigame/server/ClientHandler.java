package org.example.multigame.server;

import org.example.multigame.shared.PlayerInput;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientHandler extends Thread {
    private static int idCounter = 1;

    private int playerId;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private ServerGameLogic logic;

    public ClientHandler(Socket socket, ServerGameLogic logic) throws IOException {
        this.logic = logic;
        this.playerId = nextId();


        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());

        System.out.println("Player " + playerId + " connected");
    }
    private static synchronized int nextId() {
        return idCounter++;
    }
    public void run() {
        try {
            while (true) {
                PlayerInput input = (PlayerInput) in.readObject();
                logic.applyInput(input, playerId);

                out.writeObject(logic.state);
                out.flush();
            }
        } catch (Exception e) {
            System.out.println("Player " + playerId + " disconnected");
        }
    }
}